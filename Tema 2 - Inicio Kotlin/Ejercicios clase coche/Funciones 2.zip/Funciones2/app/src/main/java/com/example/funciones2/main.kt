package com.example.funciones2

import java.lang.NumberFormatException

// Clase coche -> Color - Velocidadmaxima - Modelo - Año de creacion
// Metodos de clase coche -> Cual es mas veloz? / Listar todos los modelos / El coche mas viejo y mas nuevo / Si el modelo es clasico o no (Anterior al año 65 o no)

class Coche(val modelo:String, val color:String, val velocidadmax:Int, val año:Int){

    fun imprimir(){
        println("Se ha creado el coche de modelo $modelo")
    }


    fun esClasico() = if (año<65) true else false
}

fun main(){

    val c1 = Coche("Seat Ibiza","Rojo",130,1999)
    val c2 = Coche("Kia Sett","Morado",150,2020)
    val c3 = Coche("Toyota Corolla","Gris",120,1950)
    val c4 = Coche("Opel Astra","Amarillo",170,2015)
    val c5 = Coche("Ford Stereo","Negro",130,1962)

    val array1 = arrayOf<Coche>(c1,c2,c3,c4,c5)
    var mas_rapido = c1;

    // Imprimir todos los coches.
    for(c in array1)
        print("Modelo: "+c.modelo+"\n"+
               "Color: "+c.color +"\n"+
                "Año: "+c.año +"\n"+
               "Velocidad: "+c.velocidadmax+"\n"
        + "=================================\n")



    for(c in array1){
        if(mas_rapido.velocidadmax < c.velocidadmax)
            mas_rapido = c
    }

    println("El coche más rapido es "+mas_rapido.modelo+" con un maximo de "+mas_rapido.velocidadmax+"Km/h")

    var mas_viejo = c1

    for(c in array1){
        if(mas_viejo.año > c.año){
            mas_viejo = c
        }
    }

    println("El modelo mas viejo es "+mas_viejo.modelo)

    var mas_nuevo = c1

    for(c in array1){
        if(mas_nuevo.año < c.año){
            mas_nuevo = c
        }
    }

    println("El modelo mas nuevo es "+mas_nuevo.modelo)

    for(c in array1){
        if(c.esClasico()){
            println("El modelo "+c.modelo+" es un clasico.")
        }else{
            println("El modelo "+c.modelo+" no es un clasico.")
        }
    }

}